from django.shortcuts import render,redirect
from django.http import HttpResponse
from .forms import HealthForm
from home.models import HealthTask
from django.contrib import messages
from django.contrib.auth import login,logout,authenticate
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

# Create your views here.
def home(request):
   return render(request,'index.html')

def health(request):
    try:
        data = HealthTask.objects.all()
        context = {"health":data}
    except Exception as e:
        context = {"health":"Data not found"}
    return render(request,'health.html',context)


def social(request):
    return render(request,'social.html')
    
def healthDetail(request,hm):
    
    fetchData = HealthTask.objects.get(name=hm) 
    print(fetchData)
   
    context = {"fetchData:":fetchData}
    
    return render(request,'projectDetail.html',context)

@login_required(login_url='login')
def healthAdd(request):
        
    form = HealthForm()
    if request.method=='POST':
        myData= HealthForm(request.POST)
        if myData.is_valid():
            myData.save()
            messages.success(request,"task added successfully")
            return redirect('health')
    context = {'form':form}

    return render(request,'healthAdd.html',context)


#update and delete not running , so removed the buttons.
def healthDelete(request,id):
    
    data = HealthTask.objects.get(id=id)
    messages.warning(request,'task deleted successfully')
    data.delete()
    return redirect('health')
    

def healthUpdate(request,id):
    myData = HealthTask.objects.get(id=id)
    updateForm = HealthForm(request.POST or None, instance=myData)
    if updateForm.is_valid():
        updateForm.save()
        messages.success(request,"task updated successfully")
        return redirect('health')
    context={"form":updateForm}
    return render(request,'healthUpdate.html',context)


def loginPage(request):
    if request.method=='POST':
        username=request.POST["Name"]
        password=request.POST["password"]
        user=authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            return redirect('login')
   

    return render(request,'login.html')

def logoutPage(request):
    # print("helo")
    logout(request)
    return redirect('home')

