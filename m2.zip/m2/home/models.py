from django.db import models


#initially was going to do 2 cruds, for 2 types of task - health task and work/social task
#due to time constraint only doing one general crud.

# Create your models here.
class SocialTask(models.Model):
    social_task_name = models.CharField(max_length=100,null=True,blank=True)
    description = models.CharField(max_length=100,null=True,blank=True)
    social_task_date= models.DateField()
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.social_task_name

    class Meta:
        verbose_name_plural = "SocialTasks"

class HealthTask(models.Model):
    health_task_name = models.CharField(max_length=100,null=True,blank=True)
    description = models.CharField(max_length=100,null=True,blank=True)
    health_task_date=models.DateField()
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.health_task_name

    class Meta:
        verbose_name_plural = "HealthTasks"