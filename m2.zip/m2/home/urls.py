from django.urls import path
from . import views

urlpatterns = [
    path('',views.home, name = 'home'),
    path('health/',views.health, name = 'health'),
    path('social/',views.social, name = 'social'),
    path('healthDetail/',views.healthDetail,name='healthDetail'),

    path('healthAdd/',views.healthAdd,name='healthAdd'),
    path('healthAdd/',views.healthAdd,name='healthAdd'),
    path('healthUpdate/',views.healthUpdate,name='healthUpdate'),
    path('healthDelete/',views.healthDelete,name='healthDelete'),

    path('login/',views.loginPage,name='login'),
    path('logout/',views.logoutPage,name='logout'),




]