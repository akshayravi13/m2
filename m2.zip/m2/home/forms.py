from django import forms
from .models import HealthTask



class HealthForm(forms.ModelForm):
    class Meta:
        model = HealthTask
        fields = '__all__'
