

let add = document.getElementById('increase');

let subtract = document.getElementById('decrease');

let int = document.getElementById('number');
let intX = 0;

add.addEventListener('click',() =>{

    intX +=1;
    int.innerHTML = intX;

})

subtract.addEventListener('click',() =>{
    if  (intX >=1)
    {
    intX -= 1
    int.innerHTML = intX;
    }
    
})