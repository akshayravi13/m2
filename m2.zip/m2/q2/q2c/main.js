


// Sum of first 100 natural numbers square using loop
let x = 1;
let nsum = 0;
for (x = 1; x <= 100; x++) {
 nsum = nsum + x**2;
 console.log(x);
}