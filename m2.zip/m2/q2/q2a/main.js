function myFunction(){
    let number=34;
    document.getElementById("number1").innerHTML=number;
}