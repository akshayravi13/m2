function myfunction(){
    let x=1;
    let y=2;
    let sum= x+y;
    document.getElementById("number").innerHTML=number;
}

    
